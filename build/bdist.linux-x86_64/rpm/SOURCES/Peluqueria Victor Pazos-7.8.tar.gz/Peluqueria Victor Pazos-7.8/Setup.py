from distutils.core import setup

setup(name="Peluqueria Victor Pazos",
      version="7.8",
      description="Aplicacion que consulta citas en una peluqueria",
      author="Ruben Fernandez gonzalez",
      author_email="rfernandezgonzalez@danielcastelao.org",
      url="http://danielcastelao.com",
      license="GPL",
      scripts=["Peluqueria.py"],


      )