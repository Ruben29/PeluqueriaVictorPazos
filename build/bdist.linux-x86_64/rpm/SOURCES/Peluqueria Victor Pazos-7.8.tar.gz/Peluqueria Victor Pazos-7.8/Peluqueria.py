# -*- coding: utf-8 -*-

import sqlite3 as clientes
from gi.repository import Gtk

settings = Gtk.Settings.get_default()
settings.props.gtk_button_images = True
class Clientes:
    #Creamos acceso a las ventanas de glade
    archivoVentanaPrincipal = "VentanaPrincipal.glade"
    archivoVentanaConsulta = "ConsultaClientes.glade"
    archivoVentanaIntroducir = "CrearCliente.glade"
    archivoVentanaEliminar = "EliminarCliente.glade"

    archivoVentanaArticuloEliminado = "VentanaArticuloEliminado.glade"
    #Creamos constructores de GTK para las interfaces

    builderVentanaPrincipal = Gtk.Builder()
    builderVentanaConsulta = Gtk.Builder()
    builderVentanaIntroducir = Gtk.Builder()
    builderVentanaEliminar = Gtk.Builder()
    builderVentanaArticuloEliminado = Gtk.Builder()
    #Añadimos los archivos a los constructores de la interface









    builderVentanaPrincipal.add_from_file(archivoVentanaPrincipal)
    builderVentanaConsulta.add_from_file(archivoVentanaConsulta)
    builderVentanaIntroducir.add_from_file(archivoVentanaIntroducir)
    builderVentanaEliminar.add_from_file(archivoVentanaEliminar)


    #Recogemos las ventanas contenedoras
    ventanaEntrada = builderVentanaPrincipal.get_object("VentanaPrincipal")
    ventanaConsultas = builderVentanaConsulta.get_object("VentanaConsulta")
    ventanaIntroducir = builderVentanaIntroducir.get_object("VentanaIntroducir")
    ventanaEliminar = builderVentanaEliminar.get_object("VentanaEliminar")


    ventanaEntrada.show_all()
    #Conectamenos a la base de datos y creamos un cursor para recorrerla
    bd = clientes.connect("clientes.dat")
    print(bd)
    cursor = bd.cursor()



#Funciones de búsqueda y modificación:
    def al_buscar(self, busqueda):
        self.cajaNombreConsultar.set_text("")
        self.cajaPrecioConsultar.set_text("")

        self.cajaNumeroConsultar.set_text("")

        self.cajaApellidosConsultar.set_text("")


#Recogemos el codigo de la caja de texto
        hora = self.cajaHoraConsultacion.get_text()
#Buscamos el codigo recogido en la base de datos
        self.cursor.execute("Select * from clientes where Hora='"+hora+"'")
#Recorremos el cursor y mostraremos por pantalla si existe
        for cliente in self.cursor:
         self.cajaNombreConsultar.set_text(str(cliente[1]))
         self.cajaPrecioConsultar.set_text(str(cliente[4]))

         self.cajaTratamientoConsultar.set_text(str(cliente[6]))
         self.cajaNumeroConsultar.set_text(str(cliente[7]))
         self.cajaPeluqueroConsultar.set_text(str(cliente[5]))
         self.cajaApellidosConsultar.set_text(str(cliente[2]))






    def introducirStock(self, introducir):
        nombre = self.cajaIntroducirNombre.get_text().upper()
        apellidos = self.cajaIntroducirApellidos.get_text().upper()
        hora = self.boxIntroducirHora.get_active_text()
        precio = self.cajaIntroducirPrecio.get_text().upper()
        peluquero = self.comboPeluquero.get_active_text()
        numero = self.cajaIntroducirNumero.get_text().upper()
        dni = self.cajaIntroducirDni.get_text().upper()
        tratamiento=self.comboTratamiento.get_active_text()
        self.limpiarIntroducir(self)

        self.cursor.execute("select nombre from clientes")
        #Recogemos los codigos de los productos para despues descartar si esta o no en la base
        codigos = self.cursor.fetchall()
        existe=False
        for producto in codigos:

            idCompare = str(producto)
            #Si esta en la base; existe pasa a True y no se añadirá a la base
            if idCompare[2:4]==nombre:
                print("Hora de inserccion repetida")

                existe=True

        if existe==False:
            #Introducimos valores en la tabla
            self.cursor.execute("insert into clientes values('" + dni + "','" + nombre + "','" + apellidos + "','" + hora + "','" + precio + "','"+peluquero+"','" + tratamiento + "','" + numero+ "')")
            print(" Cliente Insertado")
            #Importante efectuar commits en cada modificacion para asegurarnos la integridad de los datos en la misma
            self.bd.commit()

        existe=False


    def al_modificar(self, modificacion):
        #Definimos variables de texto que recogeran el texto que hay en las cajas


        nombre = self.cajaNombreConsultar.get_text().upper()
        precio = self.cajaPrecioConsultar.get_text().upper()

        tratamiento = self.cajaTratamientoConsultar.get_text()
        peluquero = self.cajaPeluqueroConsultar.get_text().upper()
        apellidos = self.cajaApellidosConsultar.get_text().upper()
        hora = self.cajaHoraConsultacion.get_text().upper()
        numero = self.cajaNumeroConsultar.get_text().upper()
        #Actualizamos los datos de la tabla en esa posicion mediante un Update
        self.cursor.execute(
            "update clientes set Nombre='" + nombre + "',Apellidos='" + apellidos + "',Hora='" + hora + "',Precio='" + peluquero +"',Peluquero='" + peluquero +"'"+" where Hora='" + hora + "'")




        print("Cliente Modificado")
        #Importante efectuar commits en cada modificacion para asegurarnos la integridad de los datos en la misma
        self.bd.commit()
        #Borramos las cajas usadas ya actualizadas
        self.cajaNombreConsultar.set_text("")
        self.cajaPrecioConsultar.set_text("")
        self.cajaTratamientoConsultar.set_text("")
        self.cajaNumeroConsultar.set_text("")
        self.cajaApellidosConsultar.set_text("")
        self.cajaPeluqueroConsultar.set_text("")


    def Eliminar(self, eliminado):
        #Recoje el codigo al igual que la función buscar; la diferencia es que esta ejecute un delete pasando como parámetro el código
        cajaEliminar = self.cajaEliminar.get_text()
        self.cursor.execute("delete from clientes where Hora ='" + cajaEliminar + "'")
        print("Cliente Borrado")

        #Importante efectuar commits en cada modificacion para asegurarnos la integridad de los datos en la misma
        self.bd.commit()
        #Borramos la caja de Eliminar ya usada
        self.cajaEliminar.set_text("")



#Funciones de limpieza de cajas de texto según Ventana
    def click_limpiarConsulta(self,limpieza):
        self.cajaHoraConsultacion.set_text("")
        self.cajaNombreConsultar.set_text("")
        self.cajaPrecioConsultar.set_text("")
        self.cajaTratamientoConsultar.set_text("")
        self.cajaPeluqueroConsultar.set_text("")
        self.cajaApellidosConsultar.set_text("")
        self.cajaNumeroConsultar.set_text("")




    def limpiarIntroducir(self, introduccion):
        self.cajaIntroducirNombre.set_text("")
        self.cajaIntroducirApellidos.set_text("")

        self.cajaIntroducirPrecio.set_text("")
        self.cajaIntroducirDni.set_text("")
        self.cajaIntroducirNumero.set_text("")





#Funciones de muestra y ocultacion de ventanas según clicks:
    def click_introducir(self, entrada):
        self.ventanaEntrada.hide()
        self.ventanaIntroducir.show_all()


    def click_consultar(self, consulta):
        self.ventanaEntrada.hide()
        self.ventanaConsultas.show_all()


    def Eliminar_articulo(self,eliminado):
        self.ventanaEntrada.hide()
        self.ventanaEliminar.show_all()



#Funciones de vuelta a la ventana principal
    def click_volverConsulta(self, vuelta):
        self.click_limpiarConsulta(self)
        self.ventanaConsultas.hide()
        self.ventanaEntrada.show_all()


    def volverIntroducir(self, vuelta):
        self.limpiarIntroducir(self)
        self.ventanaIntroducir.hide()
        self.ventanaEntrada.show_all()


    def volverEliminar(self, vuelta):
        self.cajaEliminar.set_text("")
        self.ventanaEliminar.hide()
        self.ventanaEntrada.show_all()



#Declaración Inicial de handlers(manejadores, señales) y entrada de ventana Principal al iniciar la aplicación
    def __init__(self):
        #Mostramos la ventana principal
        self.ventanaEntrada.show_all();
        #Manejadores; funciones definidas en Glade con su equivalencia en Python
        manejadores = {
                  "click_limpiarConsulta":self.click_limpiarConsulta,
                  "click_volverConsulta":self.click_volverConsulta,
                  "limpiarCamposIntroducir":self.limpiarIntroducir,
                  "click_introducirStock":self.introducirStock,
                  "Eliminar_articulo":self.Eliminar_articulo,
                  "click_introducir": self.click_introducir,
                  "volverIntroducir":self.volverIntroducir,
                  "click_consultar": self.click_consultar,
                  "volverEliminar":self.volverEliminar,
                  "click_modificar":self.al_modificar,


                  "al_buscar":self.al_buscar,
                  "Terminar1":self.Terminar,
                  "Terminar2":self.Terminar,
                  "Terminar3":self.Terminar,
                  "Terminar":self.Terminar,
                  "Eliminar":self.Eliminar,

        }
        #Conectamos los constructores con los manejadores
        self.builderVentanaPrincipal.connect_signals(manejadores)
        self.builderVentanaConsulta.connect_signals(manejadores)
        self.builderVentanaIntroducir.connect_signals(manejadores)
        self.builderVentanaEliminar.connect_signals(manejadores)

        self.builderVentanaArticuloEliminado.connect_signals(manejadores)

        #Recojemos las cajas de las ventanas
        self.cajaHoraConsultacion = self.builderVentanaConsulta.get_object("cajaHoraConsultacion")

        self.cajaNombreConsultar = self.builderVentanaConsulta.get_object("cajaNombreConsultar")
        self.consolaVenta = self.builderVentanaConsulta.get_object("LConsola")
        self.cajaDniConsultar=self.builderVentanaConsulta.get_object("cajaDniConsultar")
        self.cajaPrecioConsultar = self.builderVentanaConsulta.get_object("cajaPrecioConsultar")
        self.cajaNumeroConsultar = self.builderVentanaConsulta.get_object("cajaNumeroConsultar")
        self.cajaApellidosConsultar = self.builderVentanaConsulta.get_object("cajaApellidosConsultar")
        self.cajaPeluqueroConsultar = self.builderVentanaConsulta.get_object("cajaPeluqueroConsultar")
        self.cajaTratamientoConsultar = self.builderVentanaConsulta.get_object("cajaTratamientoConsultar")
        self.cajaIntroducirNombre = self.builderVentanaIntroducir.get_object("cajaIntroducirNombre")
        self.cajaIntroducirDni = self.builderVentanaIntroducir.get_object("cajaIntroducirDni")
        self.cajaIntroducirNumero = self.builderVentanaIntroducir.get_object("cajaIntroducirNumero")
        self.cajaIntroducirApellidos = self.builderVentanaIntroducir.get_object("cajaIntroducirApellidos")
        self.boxIntroducirHora = self.builderVentanaIntroducir.get_object("boxIntroducirHora")
        self.comboPeluquero = self.builderVentanaIntroducir.get_object("comboPeluquero")
        self.comboTratamiento=self.builderVentanaIntroducir.get_object("comboTratamiento")
        self.cajaIntroducirPrecio = self.builderVentanaIntroducir.get_object("cajaIntroducirPrecio")
        self.cajaEliminar = self.builderVentanaEliminar.get_object("cajaEliminar")









#Función de cierre del programa
    def Terminar(self, dos, tres):
        #Cerramos todas las ventanas y el main
        self.ventanaEntrada.connect("delete-event", Gtk.main_quit)
        self.ventanaIntroducir.connect("delete-event", Gtk.main_quit)
        self.ventanaEliminar.connect("delete-event", Gtk.main_quit)
        self.ventanaConsultas.connect("delete-event", Gtk.main_quit)
        Gtk.main_quit()


Clientes()
Gtk.main()
#Queda pendiente la inclusión de pequeñas consolas  que avisen del resultado de los eventos
#(si se ha actualizado,borrado,... con exito o no) y la discriminacion de datos
#segun sean caracteres o números